<html>
<head>
<title>Additional Information</title>
  <link rel="icon" href="j.jpg">
  <link rel="stylesheet" href="add.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<script>
    function prev()
    {
        document.location.href = "2.php";
    }
</script>
<body>
	<div class="nav-bar">
		<img src="j.jpg" alt="JournalHub" class="Logo">
    <div class="Links">
      <a id="special"> <i class="fa fa-user-circle-o"> </i> <?php
          session_start();
          echo $_SESSION['Username'];
           ?> </a>&nbsp;
      	</div>
    </div>
    <form action="add.php" method="POST">
    	<hr color="orange">
    <div class="center">
      <div class="inside-center">
        <br>
        Additional Information
      </div><br><br><br><br><div class="box">
      Please Enter the name of all the co-authors separate by semicolon<br>
      <center>
          <textarea name="coauthors" cols="71" required></textarea></center>
        </div>
        <div class="box">
        Please confirm that you have mentioned all organizations that funded your research in the Acknowledgements section of your submission, including grant numbers where appropriate.<br>
      </center>
        <br>
        <input type="radio" id="fund" name="funded" required>
        I confirm that I have mentioned all organizations that funded my research in the Acknowledgements section </input></div>
        <div class="box">
          Does your submission include Data in Brief? If so, please upload all Data in Brief files (completed Word template and any relevant data files) as a single zip file, and select "Data in Brief" as File Type.<br>
<br>        <input type="radio" id="brief" name="brief" required>Yes<br>

        <input type="radio" id="nobrief" name="brief" required>No<br></div>
        <div class="box">
Does your submission include a method article (optional)? If so, please upload all MethodsX files (completed Word template and any relevant data files) as a single zip file, and select "MethodsX" as File Type.
<br>
<br>
      <input type="radio" id="article" name="article" required>Yes<br>

      <input type="radio" id="noarticle" name="article" required>No</div><br>
      </div>
      <button type="submit" class = "button" name = "s"><span>Proceed </span></button>
      <button class="b" onclick = "prev()"><span>Back </span></button>
  </form>
</body>
<?php
  $id = $_SESSION['IDab'];
  if(isset($_POST['s']))
  {
      $co = $_POST['coauthors'];
      $link = mysqli_connect("localhost","root","","se project");
      if(!$link)
      {
          echo "Couldn't connect Database Please check the Connection.";
      }
      mysqli_query($link, "update info set coauthors = '$co' where ID = '$id'");
      echo "<script>window.location.href='5.php';</script>";
  }
?>
</html>
