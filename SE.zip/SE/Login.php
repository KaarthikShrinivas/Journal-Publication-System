<!DOCTYPE html>
<html>
<head>
  <title>JournalHub</title>
  <link rel="icon" href="Icon.PNG">
  <link rel="stylesheet" href="Login1.css">
  <script type="text/javascript">
    function changeContent()
    {
        window.location.href = "SignUp.php";
    }
  </script>

</head>
  <body>
    <img src="Logo.PNG" alt="JournalHub" class="Logo">
    <hr color="orange">
    <div class="containerMain">
      <div class="Login" id="notghost1">
        <form action="" method="post">
            <h2>Sign In</h2>
            <input type="text" name="Iusername" placeholder="Username"  required> <br><br>
            <input type="password" name="Ipassword" placeholder="Password" required> <br> <br>
            <input type= "radio" name="userLevel" value="Admin" required> Editor  <input type= "radio" name="userLevel" value="User" required> Author <input type= "radio" name="userLevel" value="Reviewer" required> Reviewer<br><br>
            <br>
            <input type="submit" name="Lsubmit" value="SIGN IN">
        </form>
      </div>
      <div class="SignupInfo">
        <h2>Hello, Friend!</h2>
        <p>Enter Your Details and join our quest for knowledge</p>
        <input type="button" value="Sign Up" onclick="changeContent()">
      </div>
    </div>
    <?php
    if(isset($_POST['Lsubmit']))
    {
        $link = mysqli_connect("localhost","root","","se project");
        if(!$link)
        {
          echo "Couldn't connect Database Please check the Connection.";
        }
        $Username = $_POST['Iusername'];
        $Password = $_POST['Ipassword'];
        $UserStatus = $_POST['userLevel'];
        $queryFirst = mysqli_query($link,"select * from login where Username = '$Username' limit 1");
        $resultFirst = mysqli_fetch_array($queryFirst);
        $query = mysqli_query($link,"select * from login where Username = '$Username' and Password='$Password' and UserStatus = '$UserStatus' limit 1");
        $result = mysqli_fetch_array($query);

        if(empty($resultFirst))
        {
          echo "<script>alert('Username Does not Exists');</script>";
        }
        elseif(empty($result))
        {
          echo "<script>alert('Username and Password or Status Do not Match');</script>";
        }
        else
        {
          session_start();
          $_SESSION['Username'] = $Username;
          $_SESSION['Status'] = $result['UserStatus'];
          if($result['UserStatus']=="Admin")
          {
            header("Location: ../SE/AdminFirstPage.php");
            exit();
          }
          elseif($result['UserStatus']=="Reviewer")
          {
            header("Location: ../SE/ReviewerFirstPage.php");
            exit();
          }
          else {
            header("Location: ../SE/Author_Main_Menu.php");
            exit();
          }
        }
    }
     ?>
  </body>
</html>
