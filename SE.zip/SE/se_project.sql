-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 11, 2020 at 06:54 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `se project`
--

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `ID` int(11) NOT NULL,
  `Username` text NOT NULL,
  `Title` text NOT NULL,
  `Classifications` text NOT NULL,
  `Type` text NOT NULL,
  `Coauthors` text NOT NULL,
  `Comments` text NOT NULL,
  `Abstract` text NOT NULL,
  `Keywords` text NOT NULL,
  `Funds` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`ID`, `Username`, `Title`, `Classifications`, `Type`, `Coauthors`, `Comments`, `Abstract`, `Keywords`, `Funds`) VALUES
(148, 'Kaarthik', 'Software Engineering', 'Software Engineering;Data Structures;Algorithms;', 'Research Paper', 'Kaarthik;Dhanish;Girish', '', '', 'Loreum Ipsum', 'VIT Chennai');

-- --------------------------------------------------------

--
-- Table structure for table `journals`
--

CREATE TABLE `journals` (
  `ID` int(11) NOT NULL,
  `Username` text NOT NULL,
  `ApprovalStatus` text NOT NULL,
  `RApproval` text NOT NULL,
  `FileName` text NOT NULL,
  `ReviewerAssigned` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `journals`
--

INSERT INTO `journals` (`ID`, `Username`, `ApprovalStatus`, `RApproval`, `FileName`, `ReviewerAssigned`) VALUES
(54, 'Kaarthik', 'Approved', 'Approved', '148_148_doc1.pdf', 'Set');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `ID` int(11) NOT NULL,
  `Username` text NOT NULL,
  `Email` text NOT NULL,
  `Password` text NOT NULL,
  `UserStatus` text NOT NULL,
  `FirstName` text NOT NULL,
  `LastName` text NOT NULL,
  `Country` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`ID`, `Username`, `Email`, `Password`, `UserStatus`, `FirstName`, `LastName`, `Country`) VALUES
(2, 'Editor', 'journalhubteam1@gmail.com', 'a1', 'Admin', '', '', ''),
(3, 'Reviewer1', 'Reviewer1@gmail.com', 'a1', 'Reviewer', '', '', ''),
(4, 'Reviewer2', 'Reviewer2@gmail.com', 'a2', 'Reviewer', '', '', ''),
(6, 'Author', 'authorrriwp@gmail.com', 'a1', 'User', 'Girish', 'Sudhakar', 'India'),
(8, 'Kaarthik ', 'kaarthikshrinivas18a2002@gmail.com', 'kaarthik', 'User', 'Kaarthik', 'Vordhi', 'India');

-- --------------------------------------------------------

--
-- Table structure for table `reviewerstable`
--

CREATE TABLE `reviewerstable` (
  `ID` int(11) NOT NULL,
  `JournalID` int(11) NOT NULL,
  `FileName` text NOT NULL,
  `ReviewersSugg` text NOT NULL,
  `RApproval` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reviewerstable`
--

INSERT INTO `reviewerstable` (`ID`, `JournalID`, `FileName`, `ReviewersSugg`, `RApproval`) VALUES
(21, 54, '148_148_doc1.pdf', 'Reviewer1', 'Approved');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `journals`
--
ALTER TABLE `journals`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `reviewerstable`
--
ALTER TABLE `reviewerstable`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;

--
-- AUTO_INCREMENT for table `journals`
--
ALTER TABLE `journals`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `reviewerstable`
--
ALTER TABLE `reviewerstable`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
