<!DOCTYPE html>
<html>
  <head>
    <title>Journal Hub</title>
    <link rel="icon" href="Icon.PNG">
    <link rel="stylesheet" href="file.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>
    <div class="nav-bar">
      <img src="j.jpg" alt="JournalHub" class="Logo">
      <div class="links">
      <a id="special"> <i class="fa fa-user-circle-o"> </i>
        <?php
      session_start();
      echo $_SESSION['Username'];
       ?> </a>
      <a href="Logout.php">Logout</a>
      </div>
    </div>
    <hr color="orange">
    <div class="center">
      <form action="" method="post" enctype="multipart/form-data">
        <fieldset>
          <legend>Sample upload</legend>
          <br>
          Please Select a file
          <br>
          <div class="ProceedBut">
          <input type="file" name="files"><br><br>
          <input type="submit" name="submits" value="submit"><br>
          <br>
        </div>
          <br><br>
        </fieldset>
      </form>
      <br>
      </div>
    </div>

    <?php
    if(isset($_POST['submits']))
    {

      $id = $_SESSION['IDab'];
      $file = $_FILES['files'];

      $fileName = $_FILES['files']['name'];
      $fileTmpName = $_FILES['files']['tmp_name'];  //Temporary Location of the File
      $fileError = $_FILES['files']['error'];
      $fileType = $_FILES['files']['type'];

      $fileExt  = explode('.', $fileName);
      $fileActualExt = strtolower(end($fileExt)); //takes the last value in the array and convert to lower to compare

      $allowed = array('pdf'); //to save what kind of file are allowed to upload

      if (in_array($fileActualExt,$allowed))
      {
        if($fileError === 0)
        {
          $fileNameNew = $_SESSION['IDab']."_".$fileName;

          $fileDestination = "JournalFiles/".$fileNameNew;
          move_uploaded_file($fileTmpName,$fileDestination); //Uploaded File to the Destination from temporary destination

          //Connecting to Data Base
          $link = mysqli_connect("localhost","root","","se project");
          if(!$link)
          {
            echo "Couldn't connect Database Please check the Connection.";
          }




          $id = $_SESSION['IDab'];

          require("fpdf.php");
          $pdf = new FPDF();
          $pdf->AddPage();
          $pdf->SetLineWidth(2);
          $pdf->SetFont("Arial","B",20);
          $pdf->Cell(0,30,"Author's Details",1,1,"C");
          $pdf->Ln(20);

          $pdf->SetLineWidth(1);
          $pdf->SetTextColor(220,50,50);
          $pdf->SetFont("Arial","B",13);
          $pdf->Cell(95,10,"    Username : ",1,0);
          $q1 = mysqli_query($link,"select Username from info where ID = '$id'");
          $r1 = mysqli_fetch_array($q1);
          $pdf->SetTextColor(0,0,255);
          $pdf->SetFont("Arial","I",13);
          $pdf->Cell(95,10,"    {$r1['Username']}",1,1);

          $pdf->SetLineWidth(1);
          $pdf->SetTextColor(220,50,50);
          $pdf->SetFont("Arial","B",13);
          $pdf->Cell(95,10,"    Type : ",1,0);
          $q1 = mysqli_query($link,"select Type from info where ID = '$id'");
          $r1 = mysqli_fetch_array($q1);
          $f1 = $r1['Type'];
          //$a1 = str_replace(';',"<br>",$f1);
          $pdf->SetTextColor(0,0,255);
          $pdf->SetFont("Arial","I",13);
          $pdf->Cell(95,10,"    {$f1}",1,1);

          $pdf->SetLineWidth(1);
          $pdf->SetTextColor(220,50,50);
          $pdf->SetFont("Arial","B",13);
          $pdf->Cell(95,10,"    Title : ",1,0);
          $q1 = mysqli_query($link,"select Title from info where ID = '$id'");
          $r1 = mysqli_fetch_array($q1);
          $f1 = $r1['Title'];
          $f1 = wordwrap($f1, 80, "\n", true);
          $pdf->SetTextColor(0,0,255);
          $pdf->SetFont("Arial","I",13);
          $pdf->MultiCell(0,10,"   {$f1}",1);

          $pdf->SetLineWidth(1);
          $pdf->SetTextColor(220,50,50);
          $pdf->SetFont("Arial","B",13);
          $pdf->Cell(95,10,"    Classifications : ",1,0);
          $q1 = mysqli_query($link,"select Classifications from info where ID = '$id'");
          $r1 = mysqli_fetch_array($q1);
          $f1 = $r1['Classifications'];
          $a1 = str_replace(';',", ",$f1);
          $pdf->SetTextColor(0,0,255);
          $pdf->SetFont("Arial","I",13);
          $pdf->MultiCell(0,10,"   {$a1}",1);

          $pdf->SetLineWidth(1);
          $pdf->SetTextColor(220,50,50);
          $pdf->SetFont("Arial","B",13);
          $pdf->Cell(95,10,"    Coauthors : ",1,0);
          $q1 = mysqli_query($link,"select Coauthors from info where ID = '$id'");
          $r1 = mysqli_fetch_array($q1);
          $f1 = $r1['Coauthors'];
          $a1 = str_replace(';',", ",$f1);
          $pdf->SetTextColor(0,0,255);
          $pdf->SetFont("Arial","I",13);
          $pdf->MultiCell(0,10,"   {$a1}",1);

          $pdf->SetLineWidth(1);
          $pdf->SetTextColor(220,50,50);
          $pdf->SetFont("Arial","B",13);
          $pdf->Cell(95,10,"    Abstract : ",1,0);
          $q1 =  mysqli_query($link,"select Abstract from info where ID = '$id'");
          $r1 = mysqli_fetch_array($q1);
          $f1 = $r1['Abstract'];
          //$a1 = str_replace(';',"<br>",$f1);
          $pdf->SetTextColor(0,0,255);
          $pdf->SetFont("Arial","I",13);
          $pdf->MultiCell(0,10,"   {$f1}",1);

          $pdf->SetLineWidth(1);
          $pdf->SetTextColor(220,50,50);
          $pdf->SetFont("Arial","B",13);
          $pdf->Cell(95,10,"    Keywords : ",1,0);
          $q1 = mysqli_query($link,"select Keywords from info where ID = '$id'");
          $r1 = mysqli_fetch_array($q1);
          $f1 = $r1['Keywords'];
          //$a1 = str_replace(';',"<br>",$f1);
          $pdf->SetTextColor(0,0,255);
          $pdf->SetFont("Arial","I",13);
          $pdf->MultiCell(0,10,"   {$f1}",1);

          $pdf->SetLineWidth(1);
          $pdf->SetTextColor(220,50,50);
          $pdf->SetFont("Arial","B",13);
          $pdf->Cell(95,10,"    Funds : ",1,0);
          $q1 = mysqli_query($link,"select Funds from info where ID = '$id'");
          $r1 = mysqli_fetch_array($q1);
          $f1 = $r1['Funds'];
          //$a1 = str_replace(';',"<br>",$f1);
          $pdf->SetTextColor(0,0,255);
          $pdf->SetFont("Arial","I",13);
          $pdf->MultiCell(0,10,"   {$f1}",1);

          $pdf->SetLineWidth(1);
          $pdf->SetTextColor(220,50,50);
          $pdf->SetFont("Arial","B",13);
          $pdf->Cell(95,10,"    Comments : ",1,0);
          $q1 = mysqli_query($link,"select Comments from info where ID = '$id'");
          $r1 = mysqli_fetch_array($q1);
          $f1 = $r1['Comments'];
          //$a1 = str_replace(';',"<br>",$f1);
          $pdf->SetTextColor(0,0,255);
          $pdf->SetFont("Arial","I",13);
          $pdf->MultiCell(0,10,"   {$f1}",1);

          $filename="JournalFiles/".$id.".pdf";
          $pdf->Output($filename,'F');



          require('fpdf_merge.php');

          $merge = new FPDF_Merge();

          $merge->add($filename);
          $merge->add($fileDestination);
          //$merge->output();
          $fileDestination = "JournalFiles/".$id."_".$fileNameNew;
          $merge->Output($fileDestination,'F');
          $merge->Output($fileDestination,'download');



          $FileStatus = "Pending";
          $Username = $_SESSION['Username'];
          $fileNameNew = $id."_".$fileNameNew;
          mysqli_query($link,"insert into journals(Username,ApprovalStatus,RApproval,FileName,ReviewerAssigned) values('$Username','$FileStatus','$FileStatus','$fileNameNew','$FileStatus')");

          //Mailing his file
          $name = $_SESSION['Username'];
          //Finding the Email of the User .
          $queryFindEmail = mysqli_query($link,"select * from login where Username = '$name'");
          $resultQuerye = mysqli_fetch_array($queryFindEmail);
          // Mail Function Continue
          $email = $resultQuerye['Email'];
          $to = "$name <$email>";
          $from = "journalhubteam";
          $subject = "Here is your attachment";
          $mainMessage = "Hi, here's the file you have uploaded in JournalHub.";
          $fileatt = $fileDestination;
          $fileatttype = "application/pdf";
          $fileattname = $fileNameNew;
          $headers = "From: $from";

           // File
          $file = fopen($fileatt, 'rb');
          $data = fread($file, filesize($fileatt));
          fclose($file);

           // This attaches the file
          $semi_rand = md5(time());
          $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";
          $headers .= "\nMIME-Version: 1.0\n" .
          "Content-Type: multipart/mixed;\n" .
          " boundary=\"{$mime_boundary}\"";
          $message = "This is a multi-part message in MIME format.\n\n" .
          "-{$mime_boundary}\n" .
          "Content-Type: text/plain; charset=\"iso-8859-1\n" .
          "Content-Transfer-Encoding: 7bit\n\n" .
          $mainMessage . "\n\n";

           $data = chunk_split(base64_encode($data));
          $message .= "--{$mime_boundary}\n" .
          "Content-Type: {$fileatttype};\n" .
          " name=\"{$fileattname}\"\n" .
          "Content-Disposition: attachment;\n" .
          " filename=\"{$fileattname}\"\n" .
          "Content-Transfer-Encoding: base64\n\n" .
          $data . "\n\n" .
          "-{$mime_boundary}-\n";

           // Send the email
          if(mail($to, $subject, $message, $headers))
          {
              echo "The email was sent.";
          }
          else
          {
              echo "There was an error sending the mail.";
           }

           }
          else {
          echo "<script>alert('There was an Error while Uploading files')</script>";
          }
          }
          else
          {
          echo '<script type="text/javascript">alert("File Type not supported");</script>';
          }
          }
     ?>
  </body>
</html>
