<html>
<head><title>6</title>
  <link rel="icon" href="j.jpg">
  <link rel="stylesheet" href="66.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script>
      function prev()
      {
          document.location.href = "5.php";
      }
  </script>
</head>
<body>
  <div class="nav-bar">
    <img src="j.jpg" alt="JournalHub" class="Logo">
      <div class="Links">
        <a id="special"> <i class="fa fa-user-circle-o"> </i> <?php
            session_start();
            echo $_SESSION['Username'];
             ?> </a>&nbsp;
      </div>
    <hr color="orange">
  </div>
  <form action = "" method = "POST">
  <div class="center">
    <div class="inside-center">
      <br>Tiltle
    </div><br><br><br><br>
    Full Title(required)<br><br>
    <textarea name="title" cols="100" required></textarea>
  </div>
  <div class="center">
    <div class="inside-center">
      <br>Abstract
    </div><br><br><br><br>
    Abstract(required)<br><br>
    <textarea name="abstract" cols="100" required></textarea>
  </div>
</div>
<div class="center">
  <div class="inside-center">
  <br>Keywords</div><br><br><br><br>
 Please enter keywords separated by semicolons<br><br>
<textarea name="keywords" cols="100" required></textarea>
</div>
</div>
<div class="center">
  <div class="inside-center">
<br>Coauthors</div><br><br><br><br>
 Please enter coauthors separated by semicolons<br><br>
<textarea name="coauthors" cols="100" required></textarea>
</div>
</div>
<div class="center">
  <div class="inside-center">
    <br>Funding Information</div><br><br><br><br>
 Please enter Funding Information separated by semicolons<br><br>
<textarea name="funds" cols="100" required></textarea>
  </div>
</div>
</div>
<button type="submit" class = "bu" name = "s"><span>Proceed </span></button>
<button class="but" onclick = "prev()"><span>Back </span></button>
</form>
</body>

<?php
  $id = $_SESSION['IDab'];
  if(isset($_POST['s']))
  {
      $a = $_POST['title'];
      $b = $_POST['abstract'];
      $c = $_POST['keywords'];
      $d = $_POST['funds'];
      $link = mysqli_connect("localhost","root","","se project");
      if(!$link)
      {
          echo "Couldn't connect Database Please check the Connection.";
      }
      mysqli_query($link, "update info set Title = '$a' where ID = '$id'");
      mysqli_query($link, "update info set Abstract = '$b' where ID = '$id'");
      mysqli_query($link, "update info set Keywords = '$c' where ID = '$id'");
      mysqli_query($link, "update info set Funds = '$d' where ID = '$id'");
      echo "<script>window.location.href='UserFirstPage.php';</script>";
  }
?>

</html>
