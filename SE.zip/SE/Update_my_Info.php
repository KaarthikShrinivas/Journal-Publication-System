<html>
    <head>
        <title>Update_my_Info</title>
        <link rel = "stylesheet" type = "text/css" href = "Update_my_Info1.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>

    <body>

      <form method = "post">
      <div class = "z">
          <div class="nav-bar">
          <img src="j.jpg" alt="JournalHub" class="Logo">
            <div class="Links">
              <a id="special"> <i class="fa fa-user-circle-o"> </i> <?php
              session_start();
              echo $_SESSION['Username'];
               ?> </a>&nbsp;
              <a href="Author_Main_Menu.php">MAIN MENU</a>
              <a href="Update_my_Info.php">UPDATE MY INFORMATION</a>
              <a href="1.php">SUBMIT A MANUSCRIPT</a>
              <a href="Logout.php">LOGOUT</a>
            </div>
          <hr color="orange">
      </div>

      <div class = "l">
        <div class = "p">
            <h3>Update My Information</h3>
        </div>
          <p style = "margin-left: 22px; font-size: 12px">To update any information, make the<br>changes on the form and click Submit.<br>Required fields have an asterisk next<br>to the label.</p>
          <!--button class = "b1" style = "width: 170px; font-size: 14px; position: absolute; top: 97%; left: 1%">Correspondence History</button-->
          <div class="vl"></div>






          <!--FIRST BOX-->
          <fieldset class = "q">
            <legend><b>Login Information</b></legend>

            <div class = "e">
                <pre><p><span style = "font-family: Comic Sans MS, cursive, sans-serif">The username you choose must be unique within the system.
If the one  you choose is already  in use , you will be asked
for  another.</span></p></pre>
            </div>

            <p><pre><span style = "color: red; font-family: Comic Sans MS, cursive, sans-serif">                   Username *                  <input type="text" size = "26" name = "username" id = "username" required><br>                   Password *                   <input type="password" name = "password" id = "password" size = "26" required><br>                   Re-type Password *      <input type="password" id = "retype" name = "retype" size = "26" required></span></pre></p>

            <div class = "f">
                <pre><p><span style = "font-family: Comic Sans MS, cursive, sans-serif">The default login role is the user role that will be used
if you strike the enter key when logging in and you have not
made a specific selection.</span></p></pre>
            </div>

          </fieldset>







        <fieldset class = "r">
            <legend><b>Personal Information</b></legend>
            <p><pre><span style = "color: red; font-family: Comic Sans MS, cursive, sans-serif">               Title *                                         <input type="text"  size = "26" name = "title" required>   (Mr., Mrs., Dr., etc.)<br>               Given/First Name *                     <input type="text" size = "26" name = "firstname" required></span><span style = "font-family: Comic Sans MS, cursive, sans-serif"><br>               Middle Name                               <input type = "text"  size = "26"></span><span style = "color: red"><br>        Family/Last Name *          <input type = "text"  size = "26" name = "lastname"></span><br><span style = "font-family: Comic Sans MS, cursive, sans-serif">               Degree                                        <input type = "text"  size = "26">   (Ph.D., M.D., etc.)<br>                Preferred Name                         <input type = "text"  size = "26">   (nickname)<br>                Primary Phone                             <input type = "text"  size = "26">   (including country code)<br>               Secondary Phone                         <input type = "text" size = "26">   (including country code)<br>               Secondary Phone is for      <label>          Mobile</label><input type = "radio"  size = "26">   Beeper</label><input type = "radio">   Home</label><input type = "radio">   Work</label><input type = "radio">   Admin. Asst.</label><input type = "radio"><br>               Fax Number                                <input type = "text" size = "26">   (including country code)</span><br><span font-color: "red"; style = "font-family: Comic Sans MS, cursive, sans-serif; color: red;">               E-mail Address *                         <input type = "email" size = "26" name = "email" required><br></p></pre>
            <div class = "g">
                <pre><p><span style = "font-family: Comic Sans MS, cursive, sans-serif">If entering more than one e-mail address, use a semi-colon
between each address (e.g.,
giri@journalhub.com;iris@yahoo.com)<span style = "color: red">Entering a second e-
mail address from a different e-mail provider decreases the
chance that SPAM filters will trap e-mails sent to you from
online systems.</span></p></pre>
            </div>
            <br><br><br><br><br><br><br><br>
          </fieldset>







          <fieldset class = "s">
            <legend><b>Institution Related Information</b></legend>
            <p><pre><span style = "font-family: Comic Sans MS, cursive, sans-serif">              Position                            <input type="text" size = 26><br>              Institution                       <input type="password"  size = 26>   (max 300 characters)<br>              Department                     <input type="text"  size = 26>   (max 450 characters)<br><label>              <span style = "position: absolute; top: 35.5%; left: 9.5%">Street Address</span>                                        </label><textarea type = "text" rows="4" cols="26"></textarea><br>              City                                  <input type = "text" size = "26"><br>              State or Province             <input type="text" size = "26"><br>              Zip or Postal Code            <input type = "text" size = "26"><br>              <span style = "color: red">Country or Region  *</span>         <select name="countries" id="countries" name = "countries[]" style="width:165px;">
      <option value="America">America</option>
      <option value="Australia">Australia</option>
      <option value="Brazil">Brazil</option>
      <option value="England">England</option>
      <option value="India">India</option>
      <option value="Russia">Russia</option>
      <option value="Spain">Spain</option>
      <option value="Taiwan">Taiwan</option>
    </select>   <br>              Address is for      <label>            Work</label><input type = "radio"><label>   Home</label><input type = "radio"><label>   Other</label><input type = "radio"></span></pre></p>
          </fieldset>







          <fieldset class = "t">
              <legend><b>Areas of Interest or Expertise</b></legend>
              <div class = "h">
                  <pre><p><span style = "font-family: Comic Sans MS, cursive, sans-serif; font-size: 11px"> Please indicate your areas of expertise by selecting the
 checkboxes from the pre-defined list of Classifications.</span></p></pre>
              </div>
              <br><br><br>
              <p><pre><span style = "font-family: Comic Sans MS, cursive, sans-serif; font-size: 12px">             Personal Classifications            </span></p><span style = "font-family: Comic Sans MS, cursive, sans-serif; font-size: 12px">                                                        <input type="checkbox" name="chk[]" value = "Web Programming"><label>  Web Programming</label><br>                                                        <input type="checkbox" name="chk[]" value = "Computer Networks"><label>  Computer Networks</label><br>                                                        <input type="checkbox" name="chk[]" value = "Computer Architecture"><label>  Computer Architecture</label><br>                                                        <input type="checkbox" name="chk[]" value = "Theory Of Computation"><label>  Theory Of Computation</label><br>                                                        <input type="checkbox" name="chk[]" value = "Software Engineering"><label>  Software Engineering</label><br>                                                        <input type="checkbox" name="chk[]" value = "Data Structures"><label>  Data Structures</label><br>                                                        <input type="checkbox" name="chk[]" value = "Algorithms"><label>  Algorithms</label><br>                                                        <input type="checkbox" name="chk[]" value = "Operating Systems"><label>  Operating Systems</label><br>                                                        <input type="checkbox" name="chk[]" value = "Java Programming"><label>  Java Programming</label><br><br>                                               <i>          Select 1+ Classifications</i></span></p></fieldset>





          <fieldset class = "u">
              <legend><b>Additional Information</b></legend><br>
              <input type = "checkbox">indicates affirmative response
              <center>
              <table border = 2 style = "font-size: 12px">
                  <tr>
                      <td><input type = "checkbox"></td>
                      <td>We respect your privacy. Please tick the box if you do not wish to receive news, promotions<br>and special offers about our products and services.</td>
                  </tr>
                  <tr>
                      <td><input type = "checkbox"></td>
                      <td>I acknowledge that my personal information will be accessed, used and otherwise processed <br>in accordance with the Publisher's Data User Privacy Policy and the Journal Hub's Privacy Policy.</td>
                  </tr>
              </table>
              </center>
              <br>
          </fieldset>

          <pre><button class = "b1" style = "position: absolute; top: 690%; left: 32%">Cancel</button>   <button class = "b1"  style = "position: absolute; top: 690%; left: 42%"; type = "submit" name = "submit">Submit</button></pre>

      </div>
    </form>
    <?php
      $Username = $_SESSION['Username'];
      if(isset($_POST['submit']))
      {
          $retype = $_POST['retype'];
          $password = $_POST['password'];
          $title = $_POST['title'];
          $firstname = $_POST['firstname'];
          $lastname = $_POST['lastname'];
          $email = $_POST['email'];
          $country = $_POST['countries'];
          $classifications = "";
          if(!empty($_POST['chk']))
          {
              foreach($_POST['chk'] as $a)
              {
                  $classifications .= $a;
                  $classifications .= ";";
              }
          }
          if($retype == $password)
          {
              $link = mysqli_connect("localhost","root","","se project");
              if(!$link)
              {
                  echo "Couldn't connect Database Please check the Connection.";
              }

              mysqli_query($link, "update login set FirstName = '$firstname' where Username = '$Username' ");
              mysqli_query($link, "update login set LastName = '$lastname' where Username = '$Username' ");
              mysqli_query($link, "update login set Email = '$email' where Username = '$Username' ");
              mysqli_query($link, "update login set Country = '$country' where Username = '$Username' ");
              mysqli_query($link, "update login set Password = '$password' where Username = '$Username ");
              echo "<script>window.location.href = 'Author_Main_Menu.php';</script>";
          }
          else  echo "<script> alert('Password does not match!!!'); </script>";
      }
    ?>
    </body>
</html>
