<?php
$link = mysqli_connect("localhost","root","","se project");
if(!$link)
{
  echo "Couldn't connect Database Please check the Connection.";
}
$IDtoChange = $_GET['ID'];
$StatusDecided = $_GET['ApprovalStatus'];
if($StatusDecided == 0)  //Rejection
{
  $q = "Disapproved";
  mysqli_query($link,"UPDATE journals SET RApproval='$q' WHERE ID = '$IDtoChange'");
  mysqli_query($link,"UPDATE reviewerstable SET RApproval = '$q' WHERE JournalID = '$IDtoChange'");

  //Mail
  //the subject
  $sub = "Sorry, Your File Has Been Disapproved";
  //the message
  $msg = "The Journal You have sent to Journal Hub was Disapproved by the Reviewer";
  //recipient email here
  $queryToGetUsername =mysqli_query($link,"select * from journals where ID='$IDtoChange'");
  $UR = mysqli_fetch_array($queryToGetUsername);
  $UsernameOfRejected = $UR['Username'];
  $EmailGet = mysqli_query($link,"select * from login where Username = '$UsernameOfRejected'");
  $Eg = mysqli_fetch_array($EmailGet);
  $rec = $Eg['Email'];
  //send email
  mail($rec,$sub,$msg);

//Mail to Editor
  $sub = "The Reviewer has Disapproved the Journal Submitted By ".$UsernameOfRejected;
  $msg = "The Reviewer Has Disapproved the Journal Submitted By ".$UsernameOfRejected.".\nHence the file has been Disapproved.";
  $rec = "journalhubteam1@gmail.com";
  mail($rec,$sub,$msg);

  header("Location: ../SE/ReviewerFirstPage.php");
  exit();
}
else   //Approved
{
  $qt = "Approved";
  mysqli_query($link,"UPDATE journals SET RApproval='$qt' WHERE ID = '$IDtoChange'");
  mysqli_query($link,"UPDATE reviewerstable SET RApproval = '$qt' WHERE JournalID = '$IDtoChange'");

  //Mail
  //the subject
  $sub = "Congratulations, Your File Has Been approved";
  //the message
  $msg = "The Journal You have sent to Journal Hub was Approved by the Editor and Reviewer.";
  //recipient email here
  $queryToGetUsername =mysqli_query($link,"select * from journals where ID='$IDtoChange'");
  $UR = mysqli_fetch_array($queryToGetUsername);
  $UsernameOfRejected = $UR['Username'];
  $EmailGet = mysqli_query($link,"select * from login where Username = '$UsernameOfRejected'");
  $Eg = mysqli_fetch_array($EmailGet);
  $rec = $Eg['Email'];
  //send email
  mail($rec,$sub,$msg);

  //Mail to Editor
    $sub = "The Reviewer has Approved the Journal Submitted By ".$UsernameOfRejected;
    $msg = "The Reviewer Has Approved the Journal Submitted By ".$UsernameOfRejected.".\nHence the file has been Approved.";
    $rec = "journalhubteam1@gmail.com";
    mail($rec,$sub,$msg);


  header("Location: ../SE/ReviewerFirstPage.php");
  exit();
}

 ?>
