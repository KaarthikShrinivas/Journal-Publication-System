<!DOCTYPE html>
<html>
  <head>
    <title>1</title>
    <link rel="1" href="1.PNG">
    <link rel="stylesheet" href="11.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>

  <body>
    <div class="nav-bar">
      <img src="j.jpg" alt="JournalHub" class="Logo">
        <div class="Links">
          <a id="special"> <i class="fa fa-user-circle-o"> </i> <?php
              session_start();
              echo $_SESSION['Username'];
               ?> </a>&nbsp;
        </div>
      <hr color="orange">
    </div>
    <div class="center">
      <div class="inside-center">
        <p>Select Article Type</p>
      </div>
      <form class="" action="1.php" method="post">
        <div class="sub-content">
        <select name = "type" required>
          <option value = "">None</option>
          <option value = "Research Paper">Research Paper</option>
          <option value = "Short Communication">Short Communication</option>
          <option value = "Review Article">Review Article</option>
        </select>
        </div>
    </div>
    <div class="ProceedBut">
      <button type="submit" class = "button" name = "s"><span>Proceed </span></button>
    </div>
  </form>
    <?php

      $Username = $_SESSION['Username'];
      if(isset($_POST['s']))
      {
          $type = $_POST['type'];
          $link = mysqli_connect("localhost","root","","se project");
          if(!$link)
          {
              echo "Couldn't connect Database Please check the Connection.";
          }
          mysqli_query($link, "insert into info(Username, Type) values ('$Username','$type')");
          $var =  mysqli_insert_id($link);
          $_SESSION['IDab'] = $var;
          header("Location: ../SE/2.php");
      }

    ?>

  </body>
</html>
