<!DOCTYPE html>
<html>
  <head>
    <title>Journal Hub</title>
    <link rel="icon" href="Icon.PNG">
    <link rel="stylesheet" href="AdminSecondPage.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>
    <div class="nav-bar">
      <img src="Logo.PNG" alt="JournalHub" class="Logo">
      <div class="links">
      <a id="special"> <i class="fa fa-user-circle-o"> </i> <?php
      session_start();
      echo $_SESSION['Username'];
       ?> </a>
      <a href="Logout.php">Logout</a>
      </div>
    </div>
    <div class="List">
      <table>
        <thead>
          <th>Username</th>
          <th>File</th>
          <th>Reviewers</th>
        </thead>
        <?php
        $link = mysqli_connect("localhost","root","","se project");
        if(!$link)
        {
          echo "Couldn't connect Database Please check the Connection.";
        }
        $query = mysqli_query($link,"select * from journals where ApprovalStatus='Approved' and ReviewerAssigned='Pending'");

        if(mysqli_num_rows($query)>0)
        {
          while($result = mysqli_fetch_array($query))
          {
            $queryToKnowNumberOfReviewers = mysqli_query($link,"select * from login where UserStatus = 'Reviewer'");
            $noReviewers = mysqli_num_rows($queryToKnowNumberOfReviewers);
            echo "<tr>";
            echo "<td>".$result['Username']."</td>";
            $fi = $result['FileName'];
            $fileNameOrg  = explode('.', $fi);
            echo "<td><a href = './JournalFiles/".$fi."' download>".$fi."</a></td>";
            $temp = $result['ID'];
            $s = 1;
            $n = 0;
            echo '<td>';
            echo '<form action="" method="POST">';
            while($resultReview = mysqli_fetch_array($queryToKnowNumberOfReviewers))
            {
              $tempo = $resultReview['Username'];
              echo '<input type="checkbox" name="ReviewersSuggested'.$temp.'[]" value="'.$tempo.'"> '.$tempo.'<br>';
            }
            echo '<input type="submit" name="SuggRev'.$temp.'">';
            echo '</form>';
            echo '</td>';
            echo "</tr>";
            $crazy = 'SuggRev'.$temp;
            if(isset($_POST[$crazy]))
            {
              $crazy2 = 'ReviewersSuggested'.$temp;
              if(!empty($_POST[$crazy2]))
              {
                foreach ($_POST[$crazy2] as $something )
                {
                  $ss = "Pending";
                  mysqli_query($link,"insert into reviewerstable(JournalID,FileName,ReviewersSugg,RApproval) values('$temp','$fi','$something','$ss') ");
                  mysqli_query($link,"update journals set ReviewerAssigned ='Set' where ID='$temp' ");
                }
                header("Location: ../SE/AdminFirstPage.php");
                exit();
              }

            }
            echo '</tr>';

          }
        }
        ?>

      </table>
    </div>

  </body>
</html>
