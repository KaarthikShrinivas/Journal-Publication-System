<html>
<head><title>2</title>
  <link rel="icon" href="JournalHub.jpeg">
  <link rel="stylesheet" href="2.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script>
      function prev()
      {
          document.location.href = "2.php";
      }
  </script>
</head>
<body>
  <div class="nav-bar">
    <img src="j.jpg" alt="JournalHub" class="Logo">
      <div class="Links">
        <a id="special"> <i class="fa fa-user-circle-o"> </i>
<?php
session_start();
echo $_SESSION['Username'];
?>
</a>&nbsp;</div>
    <hr color="orange">
  </div>
  <div class="center">
    <div class="inside-center">
      <br>
      Classification<br>
    </div>
    <form action="2.php" method="post">
    	<div class="sub-content">
    		<br><br><br>
    		Please select 1 or more Classifications<br><br>
  			<input type="checkbox" id="a" name="c[]" value="Web programming">
  			Web programming<br>
  			<input type="checkbox" id="b" name="c[]" value="Computer architecture">
  			Computer architecture<br>
  			<input type="checkbox" id="C" name="c[]" value="Theory of Computation">
  			Theory of Computation<br>
 			  <input type="checkbox" id="d" name="c[]" value="Software Engineering">
  			Software Engineering<br>
  			<input type="checkbox" id="e" name="c[]" value="Data Structures">
  			Data Structures<br>
  			<input type="checkbox" id="f" name="c[]" value="Algorithms">
  			Algorithms<br>
  			<input type="checkbox" id="g" name="c[]" value="Operating System">
  			Operating System<br>
  			<input type="checkbox" id="h" name="c[]" value="Java Programming">
  			Java Programming<br>
  			<input type="checkbox" id="i" name="c[]" value="Logical Circuit">
  			Logical Circuit<br>
  			<br><strong>  Selected</strong>
		</div>
  <br>
  <div class="sub-content" id="abc">
 <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
  <p id="x1" >Web programming<br></p>
  <p id="x2" >Computer architecture<br></p>
  <p id="x3" >Theory of Computation<br></p>
  <p id="x4" >Software Engineering<br></p>
  <p id="x5" >Data Structures</p>
  <p id="x6" >Audio Processing</p>
  <p id="x7" >Operating System</p>
  <p id="x8" >Java Programming<br></p>
  <p id="x9" >Logical Circuit<br></p>
</div>
</div>
  <button type = "button" class = "bu" onclick = "myFunction()"><span>Add </span></button>
  <br><br>
  <button class="b" onclick = "prev()"><span>Back </span></button>
  <button type="submit" class = "button" name = "s"><span>Proceed </span></button>
</form>
  <script>

  var q=document.getElementById("abc");
  q.style.display="none";
  var text1 = document.getElementById("x1");
  text1.style.display = "none"
  var text2 = document.getElementById("x2");
  text2.style.display = "none"
  var text3 = document.getElementById("x3");
  text3.style.display = "none"
  var text4 = document.getElementById("x4");
  text4.style.display = "none";
  var text5 = document.getElementById("x5");
  text5.style.display = "none";
  var text6 = document.getElementById("x6");
  text6.style.display = "none";
  var text7 = document.getElementById("x7");
  text7.style.display = "none";
  var text8 = document.getElementById("x8");
  text8.style.display = "none";
  var text9 = document.getElementById("x9");
  text9.style.display = "none";

  function myFunction() {
    q.style.display="block"
  var checkBox1 = document.getElementById("a");

  if (checkBox1.checked == true){
    text1.style.display = "block";
  } else {
     text1.style.display = "none";
  }
  var checkBox2 = document.getElementById("b");

  if (checkBox2.checked == true){
    text2.style.display = "block";
  } else {
     text2.style.display = "none";
  }
  var checkBox3 = document.getElementById("C");

  if (checkBox3.checked == true){
    text3.style.display = "block";
  } else {
     text3.style.display = "none";
  }
  var checkBox4 = document.getElementById("d");

  if (checkBox4.checked == true){
    text4.style.display = "block";
  } else {
     text4.style.display = "none";
  }
  var checkBox5 = document.getElementById("e");

  if (checkBox5.checked == true){
    text5.style.display = "block";
  } else {
     text5.style.display = "none";
  }
  var checkBox6 = document.getElementById("f");

  if (checkBox6.checked == true){
    text6.style.display = "block";
  } else {
     text6.style.display = "none";
  }
  var checkBox7 = document.getElementById("g");

  if (checkBox7.checked == true){
    text7.style.display = "block";
  } else {
     text7.style.display = "none";
  }
  var checkBox8 = document.getElementById("h");

  if (checkBox8.checked == true){
    text8.style.display = "block";
  } else {
     text8.style.display = "none";
  }
  var checkBox9 = document.getElementById("i");

  if (checkBox9.checked == true){
    text9.style.display = "block";
  } else {
     text9.style.display = "none";
  }
}
</script>

<?php

  $id = $_SESSION['IDab'];
  if(isset($_POST['s']))
  {
      $class = "";
      if (!empty($_POST['c']))
      {
          foreach ($_POST['c'] as $a)
          {
              $class .= $a.";";
          }
      }
      //echo $class;
      $link = mysqli_connect("localhost","root","","se project");
      if(!$link)
      {
          echo "Couldn't connect Database Please check the Connection.";
      }
      mysqli_query($link, "update info set Classifications = '$class' where ID = '$id'");
      echo "<script>window.location.href='add.php';</script>";
  }

?>

</body>
</html>
